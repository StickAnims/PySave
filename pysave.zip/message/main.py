# main version by stickyanims_

# Importing os library and savefile
import save
import os

# Main function to show how PySave works
def main():

    # message gets imported from save file
    try:
        message = save.message
    # but if no variable detected in savefile, this script restores it
    except AttributeError:
        savefile = open("save.py", "w")
        savefile.write("message = None")
        savefile.close()
    
    # if no message was written, instructions will show,
    # else it shows imported message
    if save.message == None:
        print("Message: Write something, and it'll be showed here!")
    else:
        print(f"Message: {save.message}")

    # making new message
    new_message = input('>>> ')

    if new_message == "clear": # clears message to none
        savefile = open("save.py", "w")
        savefile.write("message = None")
        savefile.close()

        # clear the window
        os.system("cls")

        # refreshing and here we go again
        save.message = None
        message = save.message
        main()
    
    else: # it just saves it
        savefile = open("save.py", "w")
        savefile.write(f"message = '{new_message}'")
        savefile.close()
        os.system("cls")

        save.message = new_message
        message = save.message
        main()

# finally launches the function
main()