Hi there!

PySave is NOT A LIBRARY, but a compilation of save systems and how you add them.
These systems are provided by different people, so they may work differently. Feel free to modify
some of them, but PLEASE ADD CREDITS TO MODDER. I'll be happy to see who made it.

That's it for now, good luck!