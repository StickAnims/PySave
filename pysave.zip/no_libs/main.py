# Alternate version by @ilovetglol
# Save given data to a file without using any libraries.

def save_data(filename, data):
    """
    Args:
    filename (str): The name of the file where data will be saved.
    data (str): The content to be written to the file.
    """
    with open(filename, 'a') as file:
        file.write(data + '\n')

# Example usage
data_to_save = "Sample data to be saved in file."
save_data('output.txt', data_to_save)